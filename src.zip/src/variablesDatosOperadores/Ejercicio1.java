package variablesDatosOperadores;

public class Ejercicio1 {
    public static void main(String[] args) {
        /*
        1. Modifica el siguiente programa para hacer que compile y funcione:
public class Suma {
public static void main(String[] args) {
int n1 = 50, n2 = 30
boolean suma = 0;
suma = n1 * n2;
System.out.println("La suma es: " + suma);
}

         */

        int n1 = 50, n2 = 30; // falta el ;
        int suma = 0;
        suma = n1 + n2;
        System.out.println("La suma es: " + suma);

    }
}
