package variablesDatosOperadores;

import java.util.Scanner;

public class Ejemplos {
    public static void main(String[] args) {
        // Tipos de variables para números con decimales
        double a = 3.4567; // en el editor, ponemos los decimales con un .
        float b = 3.4567F;

        // Cuando pedimos uno por teclado:
        Scanner sc = new Scanner(System.in);
        System.out.println("Número decimal: ");
        double d = sc.nextDouble(); // al meter por teclado, los decimales se ponen con ,
        System.out.println(d);


    }
}
