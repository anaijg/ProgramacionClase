package variablesDatosOperadores;

public class Ejercicio30 {
    public static void main(String[] args) {
        /*
        30. Di si funcionará el siguiente código; en caso afirmativo, explica qué mostrará por
pantalla. En caso negativo, explica por qué no funciona.
boolean adivina = ((97 == 'a') && true);
System.out.println(adivina);
         */
        boolean adivina = ((97 == 'a') && true);
        System.out.println(adivina);
    }
}
