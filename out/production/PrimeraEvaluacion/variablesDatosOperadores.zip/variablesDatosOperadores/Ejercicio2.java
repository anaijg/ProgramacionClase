package variablesDatosOperadores;

public class Ejercicio2 {
    public static void main(String[] args) {
        /* 2. El siguiente programa tiene 3 fallos, averigua cuáles son y modifica lo necesario para
        que funcione:
        public class Cuadrado {
            public static void main(String[] args) {
                char número = 2;
                cuad = número * número,
                        System.out.println("El cuadrado de " + número + " es: "
                                cuad);
            }
        }
         */
        int número = 2;
        int cuad = número * número;
        System.out.println("El cuadrado de " + número + " es: " + cuad);
    }
}
