package variablesDatosOperadores;

public class Ejercicio14 {
    public static void main(String[] args) {
        /*
        15. Realiza un programa que calcule la longitud de una circunferencia de radio 3 metros.
         */
        double L = 2 * Math.PI * 3;
        System.out.println(L);
    }
}
