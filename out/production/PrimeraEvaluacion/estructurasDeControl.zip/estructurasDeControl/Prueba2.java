package estructurasDeControl;

public class Prueba2 {
    public static void main(String[] args) {
        int i = 1;
        System.out.println("i==1");

    }
}
